#ifndef BINTOCOL_H
#define BINTOCOL_H

#include <opencv2/opencv.hpp> 
#include <iostream>
using namespace cv;
using namespace std;

Mat bintocol (const Mat& tableauBinaire);

#endif;