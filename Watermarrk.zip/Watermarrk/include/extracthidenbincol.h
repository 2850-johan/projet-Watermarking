
#ifndef EXTRACTHIDENBINCOL_H
#define EXTRACTHIDENBINCOL_H

#include <opencv2EX/opencv.hpp> 
using namespace cv;
using namespace std;



Mat extract(const Mat& imagehidein, int hiddenRows) ;


#endif;