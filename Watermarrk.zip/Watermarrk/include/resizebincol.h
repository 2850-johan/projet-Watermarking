#ifndef  RESIZEBINCOL_H


#define  RESIZEBINCOL_H



#include <opencv2/opencv.hpp>    

Mat resizingextract(Mat& uchiden) 

#endif

