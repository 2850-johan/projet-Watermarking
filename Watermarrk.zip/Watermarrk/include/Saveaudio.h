#ifndef SAVEAUDIO_H
#define SAVEAUDIO_H


#include <iostream>            
#include <fstream>             // Pour lire et écrire des fichiers
#include <vector>             

using namespace std;
using namespace cv;


// Fonction pour écrire les octets extraits dans un fichier audio
void sauvegarderAudio(const string& cheminFichier, const vector<unsigned char>& audioData)
#endif;