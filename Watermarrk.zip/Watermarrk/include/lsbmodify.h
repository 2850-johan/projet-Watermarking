#ifndef LSBMODIFY_H
#define LSBMODIFY_H


#include <opencv2/opencv.hpp>


#include <iostream>

using namespace std;
using namespace cv;





Mat  lsbreplace(Mat& imagehideuc ,Mat&imagehidein)

#endif
