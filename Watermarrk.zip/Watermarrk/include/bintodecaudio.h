

#ifndef BINTODECAUDIO_H
#define BINTODECAUDIO_H


#include <iostream>            

#include <vector>              
using namespace std;


vector<unsigned char> bitsToDecimal(const vector<int>& bits)

#endif