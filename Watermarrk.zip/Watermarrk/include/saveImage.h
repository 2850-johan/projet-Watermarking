#ifndef  SAVEIMAGE_H


#define  SAVEIMAGE_H
#include <opencv2/opencv.hpp>


using namespace std;

void sauvegarderImage(cv::Mat& image, string& repertoire, string& nomFichier)

#endif