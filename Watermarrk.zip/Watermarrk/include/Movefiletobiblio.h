#ifndef MOVEFILETOBIBLIO_H


#define MOVEFILETOBIBLIO_H






using namespace std;
using namespace std::filesystem;

// Fonction pour déplacer un fichier vers un répertoire qui nous sert de bibliothèque de données

void deplacerFichier(const string& cheminSource, const string& repertoireCible)
#endif
