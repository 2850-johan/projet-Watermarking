#ifndef BINARYTOTEXT_H
#define BINARYTOTEXT_H


#include <string>
using namespace std;



string binaryToText(const string& binaryString);
#endif
