#ifndef REPLACELSBTEXT_H
#define REPLACELSBTEXT_H


#include <string>
using namespace std;


Mat replaceBitsInLastColumn(const string& binaryData, Mat& imageHost)
#endif
