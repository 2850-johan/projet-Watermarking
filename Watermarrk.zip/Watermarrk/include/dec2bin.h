#ifndef DEC2BIN_H
#define DEC2BIN_H

#include <vector>
using namespace cv;
using namespace std;
vector<vector<int>> decimalToBinary(const vector<int>& arr)

#endif;