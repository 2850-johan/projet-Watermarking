#ifndef  PIXELSTOCOL_H


#define  PIXELSTOCOL_H



// Fonction pour déplacer un fichier vers un répertoire qui nous sert de bibliothèque de données

#include <vector>              


std::vector<int> extrairePixelValues(const std::string& cheminImage)
#endif
