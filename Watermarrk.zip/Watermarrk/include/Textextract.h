#ifndef TEXTEXTRACT_H
#define TEXTEXTRACT_H


#include <string>
using namespace std;



string extractBitsAsString(const Mat& imageHost, int hiddenRows) 
#endif
