#ifndef AUDIOTODEC_H
#define AUDIOTODEC_H

#include <vector>
#include <string>

std::vector<int> extraireDecimalValuesAudio(const std::string& cheminFichier);
#endif