#ifndef  RECONSTRUCTIMAGE_H


#define  RECONSTRUCTIMAGE_H



// Fonction pour déplacer un fichier vers un répertoire qui nous sert de bibliothèque de données

#include <opencv2/opencv.hpp>         


cv::Mat reconstruireImage(const std::vector<int>& pixelValues, int width, int height)
#endif
